package com.quizence.quizence;

import java.io.Serializable;

/**
 * Created by Mustapha Adeyosola on 26-Mar-20.
 */

public class CoursesBackbone implements Serializable {

    private int mCourseId;
    private String mCourseName;
    private int mCourseQuestionsTotal;
    private int mDrawable;
    private Object mCourseStats;

    public CoursesBackbone(int courseId, String courseName, int courseQuestionsTotal, int drawable){
        mCourseId = courseId;
        mCourseName = courseName;
        mCourseQuestionsTotal = courseQuestionsTotal;
        mDrawable = drawable;
    }

    public void setCourseName(String courseName){}

    public String getCourseName(){
        return mCourseName;
    }

    public int getCourseId(){
        return mCourseId;
    }

    public int getCourseQuestionsTotal(){
        return mCourseQuestionsTotal;
    }

    public int getDrawable(){
        return mDrawable;
    }
}
