package com.quizence.quizence;

import android.content.Context;
import android.util.Log;

import com.quizence.quizence.model.MCQmodel;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Mustapha Adeyosola on 26-Mar-20.
 */

public class QuizenceDataHolder {

    private static QuizenceDataHolder sQuizenceDataHolder;
    private List<CoursesBackbone> mCourses;
    private List<MCQmodel> mMCQquestions;

    private QuizenceDataHolder(){
        mCourses = new ArrayList<>();

        CoursesBackbone coursesBackbone1 = new CoursesBackbone(0, "Paediatrics", 20, R.drawable.paediatrics);
        mCourses.add(coursesBackbone1);

        CoursesBackbone coursesBackbone2 = new CoursesBackbone(0, "OBGYN", 10, R.drawable.obgyn);
        mCourses.add(coursesBackbone2);

        CoursesBackbone coursesBackbone3 = new CoursesBackbone(0, "Medicine", 40, R.drawable.medicine);
        mCourses.add(coursesBackbone3);

        CoursesBackbone coursesBackbone4 = new CoursesBackbone(0, "Surgery", 35, R.drawable.surgery);
        mCourses.add(coursesBackbone4);

        CoursesBackbone coursesBackbone5 = new CoursesBackbone(0, "Psychiatry", 60, R.drawable.psychiatry);
        mCourses.add(coursesBackbone5);
    }

    public static QuizenceDataHolder get(){
        if(sQuizenceDataHolder == null){
            sQuizenceDataHolder = new QuizenceDataHolder();
        }
        return sQuizenceDataHolder;
    }

    public List<CoursesBackbone> getCourses(){
        return mCourses;
    }

    public List<MCQmodel> getQuestions(String filename, Context context){
        if(mMCQquestions == null){
            BufferedReader reader = null;
            StringBuilder fileText = new StringBuilder();

            try {
                reader = new BufferedReader(new InputStreamReader(context.getAssets().open(filename)));
                String eachLine;
                while((eachLine = reader.readLine()) != null){
                    fileText.append(eachLine).append("\n");
                }
//                Log.v("fileText", fileText.toString());
                return parseJSON(fileText.toString(), context);
            } catch (Exception e) {
                e.printStackTrace();
                Log.v("File Opening Error", e.getMessage());
            } finally {
                try {
                    if(reader != null) reader.close();
                } catch (IOException e) {
                    Log.v("File Closing Error", e.getMessage());
                }
            }

            try {
                parseJSON(filename, context);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        return mMCQquestions;
    }

    public void clearQuestionsList(){
        if(mMCQquestions.size() != 0) mMCQquestions = null;
    }

    private List<MCQmodel> parseJSON(String readFile, Context context) throws JSONException {
        mMCQquestions = new ArrayList<>();
        JSONArray jsonArray = new JSONArray(readFile);
        for(int i = 0; i < jsonArray.length(); i++){
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            MCQmodel mcqmodel = new MCQmodel(jsonObject.getString("title"), jsonObject.getJSONArray("options"), i + 1);
            mMCQquestions.add(mcqmodel);
        }

        return mMCQquestions;
    }
}
