package com.quizence.quizence.bestoption;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.quizence.quizence.QuizModeListAdapter;
import com.quizence.quizence.QuizenceDataHolder;
import com.quizence.quizence.R;
import com.quizence.quizence.model.MCQmodel;

import java.util.List;

/**
 * Created by Mustapha Adeyosola on 30-Mar-20.
 */

public class QuizModeListFragment extends Fragment {

    private List<MCQmodel> mMCQquestions;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mMCQquestions = QuizenceDataHolder.get().getQuestions("obsgyn.json", getActivity());
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_quiz_mode_list, container, false);
        RecyclerView recyclerView = view.findViewById(R.id.fragment_quiz_mode_list_recyclerview);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        recyclerView.setAdapter(new QuizModeListAdapter(mMCQquestions, getActivity()));

        return view;
    }
}
