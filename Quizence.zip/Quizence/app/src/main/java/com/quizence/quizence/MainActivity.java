package com.quizence.quizence;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private String[] mDashboardItems = {
            "Recommended Reading", "Question of the Day", "Common Ward Questions"
    };

    private int[] mDashboardIcons = {
            R.drawable.ic_book_black_24dp, R.drawable.ic_assessment_black_24dp, R.drawable.ic_help_black_24dp, R.drawable.ic_note_black_24dp
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar quizenceToolbar = findViewById(R.id.quizence_appbar);
        setSupportActionBar(quizenceToolbar);
        if(getSupportActionBar() != null) getSupportActionBar().setTitle(R.string.dashboard);

        ImageView imageView = findViewById(R.id.activity_main_avatar);
        imageView.setClipToOutline(true);

        GridView dashboardGridView = findViewById(R.id.dashboard_gridview);
        dashboardGridView.setAdapter(new BaseAdapter() {
            @Override
            public int getCount() {
                return mDashboardItems.length;
            }

            @Override
            public String getItem(int position) {
                return mDashboardItems[position];
            }

            @Override
            public long getItemId(int position) {
                return position;
            }

            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                if(convertView == null) convertView = getLayoutInflater().inflate(R.layout.gridview_layout, parent, false);

                CardView cardView = convertView.findViewById(R.id.gridview_root);
                cardView.setMinimumHeight(cardView.getWidth());

                //set the icon for the imageview
                ImageView iconImgView = convertView.findViewById(R.id.main_section_icon);
                iconImgView.setImageResource((mDashboardIcons[position]));

                //set the text for the textview
                TextView textView = convertView.findViewById(R.id.main_section_text);
                textView.setText(mDashboardItems[position]);
                return convertView;
            }
        });

    }

    public void launchSelectionActivity(View view){
        Intent selectionIntent = new Intent(this, SelectionActivity.class);
        startActivity(selectionIntent);
    }
}
