package com.quizence.quizence;

import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

public class QuizModeActivity extends AppCompatActivity {

    private FragmentManager mFragmentManager;
    private FragmentTransaction mFragmentTransaction;
    private Button mMultiViewButton;
    private Button mSingleViewButton;
    private QuizModeSwipeFragment mQuizModeSwipeFragment;
    private QuizModeListFragment mQuizModeListFragment;
    private int mClickCount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz_mode);

        Toolbar quizenceToolbar = findViewById(R.id.quizence_appbar);
        setSupportActionBar(quizenceToolbar);

//        mSingleViewButton = findViewById(R.id.activity_quiz_mode_singleview);
//        mMultiViewButton = findViewById(R.id.activity_quiz_mode_multiview);

//        TextView logger = findViewById(R.id.logger_textview);
//        logger.setText(QuizenceDataHolder.get().getQuestions("obsgyn.json", this).get(0).getQuestionTitle());
//
//        FrameLayout fragmentParent = findViewById(R.id.activity_quiz_mode_fragment_slot);
//
//        mFragmentManager = getSupportFragmentManager();
        mQuizModeSwipeFragment = new QuizModeSwipeFragment();
        mQuizModeListFragment = new QuizModeListFragment();
//        mFragmentTransaction = mFragmentManager.beginTransaction();
//
//        Fragment fragment = mFragmentManager.findFragmentById(R.id.activity_quiz_mode_fragment_slot);
//        if(fragment == null){
//            mFragmentTransaction.add(R.id.activity_quiz_mode_fragment_slot, mQuizModeSwipeFragment);
//        }else mFragmentTransaction.replace(R.id.activity_quiz_mode_fragment_slot, mQuizModeSwipeFragment);
//
//        mFragmentTransaction.commit();

        changeQuizMode();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.mode_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.change_view:
                changeQuizMode();
                return true;

                default:
                    return super.onOptionsItemSelected(item);
        }
    }

    private void changeQuizMode(){
        Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.activity_quiz_mode_fragment_slot);
        FragmentTransaction fragmentTransaction1 = getSupportFragmentManager().beginTransaction();

        if((mClickCount % 2) == 0){
            if(fragment != null) fragmentTransaction1.remove(fragment);
            fragmentTransaction1.replace(R.id.activity_quiz_mode_fragment_slot, new QuizModeSwipeFragment()).commit();
            Toast.makeText(this, "even clickcount= " + mClickCount , Toast.LENGTH_SHORT).show();
        }else{
            if(fragment != null) fragmentTransaction1.remove(fragment);
            fragmentTransaction1.replace(R.id.activity_quiz_mode_fragment_slot, mQuizModeListFragment).commit();
            Toast.makeText(this, "odd clickcount= " + mClickCount, Toast.LENGTH_SHORT).show();
        }

        mClickCount++;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

        QuizenceDataHolder.get().clearQuestionsList();
    }
}