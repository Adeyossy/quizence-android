package com.quizence.quizence.model;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Mustapha Adeyosola on 03-Apr-20.
 */

public class MCQOptionModel implements Parcelable {

    private String mOption;
    private boolean mIsAnswer, mIsMarked;
    private int mUserAnswer;

    public MCQOptionModel(String option, boolean isAnswer){
        mOption = option;
        mIsAnswer = isAnswer;
    }

    private MCQOptionModel(Parcel in) {
        mOption = in.readString();
        mIsAnswer = in.readByte() != 0;
        mUserAnswer = in.readInt();
        mIsMarked = in.readByte() != 0;
    }

    public static final Creator<MCQOptionModel> CREATOR = new Creator<MCQOptionModel>() {
        @Override
        public MCQOptionModel createFromParcel(Parcel in) {
            return new MCQOptionModel(in);
        }

        @Override
        public MCQOptionModel[] newArray(int size) {
            return new MCQOptionModel[size];
        }
    };

    public void setOption(String option){
        mOption = option;
    }

    //returns the text of the option
    public String getOptionText(){
        return mOption;
    }

    public void setAnswer(boolean isAnswer){
        mIsAnswer = isAnswer;
    }

    public boolean getAnswer(){
        return mIsAnswer;
    }

    //this method is for future proofing when we introduce exam mode or want to check the answer
    //after all options are selected
    public void setUserAnswer(int userAnswer){
        mUserAnswer = userAnswer;
    }

    public int getUserAnswer(){
        return mUserAnswer;
    }

    //this method calculates the score of the user-selected option
    public int getOptionScore(){
        int isAnswer = mIsAnswer ? 1 : 2;
        if(mUserAnswer == isAnswer) return 1;
        return 0;
    }

    public void setMarked(boolean isMarked){
        mIsMarked = isMarked;
    }

    public boolean getMarked(){
        return mIsMarked;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(mOption);
        dest.writeInt(mUserAnswer);
        dest.writeByte((byte) (mIsAnswer ? 1 : 0));
        dest.writeByte((byte) (mIsMarked ? 1 : 0));
    }
}
