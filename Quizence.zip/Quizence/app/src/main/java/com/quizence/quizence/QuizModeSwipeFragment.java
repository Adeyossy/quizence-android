package com.quizence.quizence;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.quizence.quizence.model.MCQmodel;

import java.util.List;

/**
 * Created by Mustapha Adeyosola on 30-Mar-20.
 */

public class QuizModeSwipeFragment extends Fragment {

    private ViewPager mViewPager;
    private List<MCQmodel> mMCQquestions;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mMCQquestions = QuizenceDataHolder.get().getQuestions("obsgyn.json", getActivity());
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_quiz_mode_swipe, container, false);
        mViewPager = view.findViewById(R.id.fragment_quiz_mode_swipe_viewpager);
        FragmentManager fragmentManager = getActivity().getSupportFragmentManager();

        mViewPager.setAdapter(new FragmentStatePagerAdapter(fragmentManager) {
            @Override
            public SwipeFragment getItem(int position) {
                return SwipeFragment.newInstance(mMCQquestions.get(position));
            }

            @Override
            public int getCount() {
                return mMCQquestions.size();
            }
        });
        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
    }
}
